import { createApp } from "vue";
import App from "./App.vue";

// 本地测试
import Vue3DraggableFloat from '../packages'

// import Vue3DraggableFloat from "../dist/vue3-draggable-float.js";
import "../dist/style.css";

const app = createApp(App);

app.use(Vue3DraggableFloat);
// app.use(Breadcrumb)

app.mount("#app");
